/****************************************************************************/
/* Plantilla para cabeceras de funciones del cliente (rcftpclient)          */
/* Plantilla $Revision: 1.7 $ */
/* Autor: Huszak, Ioan Paul */
/* Autor: Terrón, Alejandro */
/****************************************************************************/

/**
 * Obtiene la estructura de direcciones del servidor
 *
 * @param[in] dir_servidor String con la dirección de destino
 * @param[in] servicio String con el servicio/número de puerto
 * @param[in] f_verbose Flag para imprimir información adicional
 * @return Dirección de estructura con la dirección del servidor
 */
struct addrinfo* obtener_struct_direccion(char *dir_servidor, char *servicio, char f_verbose);

/**
 * Imprime una estructura sockaddr_in o sockaddr_in6 almacenada en sockaddr_storage
 *
 * @param[in] saddr Estructura de dirección
 */
void printsockaddr(struct sockaddr_storage * saddr);

/**
 * Configura el socket
 *
 * @param[in] servinfo Estructura con la dirección del servidor
 * @param[in] f_verbose Flag para imprimir información adicional
 * @return Descriptor del socket creado
 */
int initsocket(struct addrinfo *servinfo, char f_verbose);


/**
 * Algoritmo 1 del cliente
 *
 * @param[in] socket Descriptor del socket
 * @param[in] servinfo Estructura con la dirección del servidor
 */
void alg_basico(int socket, struct addrinfo *servinfo);


/**
 * Algoritmo 2 del cliente
 *
 * @param[in] socket Descriptor del socket
 * @param[in] servinfo Estructura con la dirección del servidor
 */
void alg_stopwait(int socket, struct addrinfo *servinfo);


/**
 * Algoritmo 3 del cliente
 *
 * @param[in] socket Descriptor del socket
 * @param[in] servinfo Estructura con la dirección del servidor
 * @param[in] window Tamaño deseado de la ventana deslizante
 */
void alg_ventana(int socket, struct addrinfo *servinfo,int window);

/**
 *Modifica los campos de mensaje.
 *
 * @param[in] mensajeEntrada Mensaje a enviar
 * @param[in] numSec Numero de Secuencia del mensaje a enviar
 * @param[in] len Longitud de datos válidos en el campo buffer de rcftp_msg
 * @param[in] flags Flags del mensaje a enviar
 */
void construirRCFTP (struct rcftp_msg *mensaje, ssize_t numSec, ssize_t len, int flags, char * buff);


/** Envía un mensaje a la dirección especificada
 *
 * @param[in] s Socket
 * @param[in] sendbuffer Mensaje a enviar
 * @param[in] remote Dirección a la que enviar
 * @param[in] remotelen Longitud de la dirección especificada
 */
void enviamensaje(int s, struct rcftp_msg sendbuffer, struct sockaddr *remote, socklen_t remotelen);

/**
 * Recibe un mensaje 
 *
 * @param[in] socket Descriptor de socket
 * @param[out] buffer Espacio donde almacenar lo recibido
 * @param[in] buflen Longitud del buffer
 * @param[out] remote Dirección de la que hemos recibido
 * @param[out] remotelen Longitud de la dirección de la que hemos recibido
 * @return Tamaño del mensaje recibido
 */
ssize_t recibirmensaje(int socket, struct rcftp_msg *buffer, int buflen, struct sockaddr *remote, socklen_t *remotelen);

/**
 * Recibe un mensaje 
 *
 * @param[in] socket Descriptor de socket
 * @param[out] buffer Espacio donde almacenar lo recibido
 * @param[in] buflen Longitud del buffer
 * @param[out] remote Dirección de la que hemos recibido
 * @param[out] remotelen Longitud de la dirección de la que hemos recibido
 * @param[out] timeouts_procesados Numero de timeouts que han saltado 
 * @return Tamaño del mensaje recibido
 */
ssize_t recibirMensajeStopWait(int socket, struct rcftp_msg *buffer, int buflen, struct sockaddr *remote, socklen_t *remotelen, int *timeouts_procesados);


/**
 *
 *Determina si la respuesta es la que esperábamos.
 *
 * @param[in] recvbuffer Mensaje a comprobar
 * @return 1: es el esperado; 0: no es el esperado
 */
int respuestaEsperada(struct rcftp_msg msg_recv, struct rcftp_msg msg_send);

/**
 *
 *Determina si la respuesta es la que esperábamos.
 *
 * @param[in] recvbuffer Mensaje a comprobar
 * @return 1: es el esperado; 0: no es el esperado
 */
int respuestaEsperadaVentana(struct rcftp_msg msg_recv, struct rcftp_msg msg_send);

 /*
 * Determina si un mensaje es válido o no
 *
 * @param[in] recvbuffer Mensaje a comprobar
 * @return 1: es el esperado; 0: no es el esperado
 */
int esValido(struct rcftp_msg recvbuffer);





